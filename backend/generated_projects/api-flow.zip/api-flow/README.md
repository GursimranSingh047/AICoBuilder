⚠️ [Mock] Gemini API not configured. Add GEMINI_API_KEY to .env to enable real AI responses. (Received prompt: 
Write a complete, professional README.md for a project called "Api flow".

## D...)