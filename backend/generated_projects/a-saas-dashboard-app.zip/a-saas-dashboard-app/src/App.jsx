import React from "react";

export default function App() {
  return (
    <div className="min-h-screen bg-gray-950 text-white flex items-center justify-center">
      <h1 className="text-4xl font-bold">A Saas Dashboard App</h1>
    </div>
  );
}
